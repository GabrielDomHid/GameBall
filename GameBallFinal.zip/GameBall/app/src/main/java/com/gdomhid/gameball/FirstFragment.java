package com.gdomhid.gameball;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.gdomhid.gameball.databinding.FragmentFirstBinding;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;
    private MediaPlayer mPlayer = null;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //Pongo musica del juego
        mPlayer = MediaPlayer.create(getContext(), R.raw.game);
        mPlayer.start();
        //Segun donde hagas clic te llevo a un nivel u otro
        binding.ivLvl1.setOnClickListener(view1 -> {
            NavHostFragment.findNavController(FirstFragment.this)
                    .navigate(R.id.action_FirstFragment_to_SecondFragment);
        });
        binding.ivLvl2.setOnClickListener(view2 -> {
            NavHostFragment.findNavController(FirstFragment.this)
                    .navigate(R.id.action_FirstFragment_to_level2Fragment);
        });
        binding.ivLvl3.setOnClickListener(view3 -> {
            NavHostFragment.findNavController(FirstFragment.this)
                    .navigate(R.id.action_FirstFragment_to_level3Fragment);
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //paro la musica
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
        binding = null;
    }

}