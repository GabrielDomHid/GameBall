package com.gdomhid.gameball;

import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.gdomhid.gameball.databinding.FragmentLevel3Binding;

import java.io.IOException;

public class Level3Fragment extends Fragment {
    private FragmentLevel3Binding binding;
    private MediaPlayer player;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentLevel3Binding.inflate(inflater, container, false);
        return new BouncingBallInside(getContext(), 8);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        try {
            player = new MediaPlayer();
            AssetFileDescriptor afd = getContext().getAssets().openFd("04. DJVI - Dry Out.mp3");
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            player.prepare();
            player.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (player != null) {
            player.release();
            player = null;
        }
        binding = null;
    }

}