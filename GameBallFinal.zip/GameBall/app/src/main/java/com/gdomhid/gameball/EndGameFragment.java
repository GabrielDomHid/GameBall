package com.gdomhid.gameball;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.gdomhid.gameball.databinding.FragmentEndGameBinding;

import java.util.ArrayList;

public class EndGameFragment extends Fragment {

    private FragmentEndGameBinding binding;
    private ArrayList<Ball> balls = new ArrayList<>();
    private MediaPlayer mPlayer = null;
    public int[] colors2;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentEndGameBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initialize();

    }

    private void initialize() {
        //recibo los datos de las bolas
        Bundle bundle;
        bundle = getArguments();
        balls = bundle.getParcelableArrayList("balls");
        colors2 = bundle.getIntArray("colors2");
        //Dependiendo del nivel que va por colores asigno el color de las bolas a los edit text
        //Esa es la forma de indicar cuantas bolas hay del color
        if (colors2.length == 2) {
            binding.etColor1.setBackgroundColor(colors2[0]);
            binding.etColor2.setBackgroundColor(colors2[1]);
            binding.etColor3.setVisibility(View.GONE);
            binding.etColor4.setVisibility(View.GONE);
        } else if (colors2.length == 3) {
            binding.etColor1.setBackgroundColor(colors2[0]);
            binding.etColor2.setBackgroundColor(colors2[1]);
            binding.etColor3.setBackgroundColor(colors2[2]);
            binding.etColor4.setVisibility(View.GONE);
        } else if (colors2.length == 4) {
            binding.etColor1.setBackgroundColor(colors2[0]);
            binding.etColor2.setBackgroundColor(colors2[1]);
            binding.etColor3.setBackgroundColor(colors2[2]);
            binding.etColor4.setBackgroundColor(colors2[3]);
        }
        //Le pongo una opacidad al edit text para que se vea bien al escribir
        binding.etColor1.getBackground().setAlpha(128);
        binding.etColor2.getBackground().setAlpha(128);
        binding.etColor3.getBackground().setAlpha(128);
        binding.etColor4.getBackground().setAlpha(128);
        //Clic en el boton
        binding.bFinish.setOnClickListener(view -> {
            boolean result = devuelveResultado(); //Compruebo el resultado
            if (result) {
                //Reproduzco un sonido (DIOS)
                mPlayer = MediaPlayer.create(getContext(), R.raw.win);
                mPlayer.start();
                //Me espero 1 segundo y medio para que suene
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                //Me voy a la pantalla principal
                NavController navController = Navigation.findNavController((Activity) getContext(),
                        R.id.nav_host_fragment_content_main);
                navController.navigateUp();
                navController.navigate(R.id.FirstFragment);
            } else {
                //Sonido de que esta mal el resultado ( NI DE COÑA CHAVAL)
                mPlayer = MediaPlayer.create(getContext(), R.raw.lost);
                mPlayer.start();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //Paro la musica
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
        binding = null;
    }

    /**
     * Comprueba los datos que introduce el usuario con los datos generados
     *
     * @return si a acertado o no
     */
    public boolean devuelveResultado() {
        //guardo el numero de resultados de cada bola por color
        int[] nums = compruebaResultado();
        //Depende del nivel, que lo se dependiendo de la cantidad de colores maximos
        //Comparo si coincide la cantidad que pone el usuario con la verdad
        if (colors2.length == 2) {
            int valor1 = Integer.parseInt(String.valueOf(binding.etColor1.getText()));
            int valor2 = Integer.parseInt(String.valueOf(binding.etColor2.getText()));
            return nums[0] == valor1 && nums[1] == valor2;
        } else if (colors2.length == 3) {
            int valor1 = Integer.parseInt(String.valueOf(binding.etColor1.getText()));
            int valor2 = Integer.parseInt(String.valueOf(binding.etColor2.getText()));
            int valor3 = Integer.parseInt(String.valueOf(binding.etColor3.getText()));
            return nums[0] == valor1 && nums[1] == valor2 && nums[2] == valor3;
        } else if (colors2.length == 4) {
            int valor1 = Integer.parseInt(String.valueOf(binding.etColor1.getText()));
            int valor2 = Integer.parseInt(String.valueOf(binding.etColor2.getText()));
            int valor3 = Integer.parseInt(String.valueOf(binding.etColor3.getText()));
            int valor4 = Integer.parseInt(String.valueOf(binding.etColor4.getText()));
            return nums[0] == valor1 && nums[1] == valor2 && nums[2] == valor3 && nums[3] == valor4;
        }
        return false;
    }

    /**
     * Cuenta la cantidad de bolas de cada color
     *
     * @return array con numero de bolas de cada color
     */
    public int[] compruebaResultado() {
        int numCol1 = 0, numCol2 = 0, numCol3 = 0, numCol4 = 0;
        for (Ball ball : balls) {
            if (colors2[0] == ball.color) {
                numCol1++;
            } else if (colors2[1] == ball.color) {
                numCol2++;
            } else if (colors2[2] == ball.color) {
                numCol3++;
            } else if (colors2[3] == ball.color) {
                numCol4++;
            }
        }
        return new int[]{numCol1, numCol2, numCol3, numCol4};
    }
}