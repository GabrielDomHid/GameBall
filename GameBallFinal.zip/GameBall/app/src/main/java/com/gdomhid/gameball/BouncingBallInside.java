package com.gdomhid.gameball;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.AttributeSet;
import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import java.util.ArrayList;

public class BouncingBallInside extends View {
    private ArrayList<Ball> balls = new ArrayList<>();
    private int numBalls;
    public Integer colors[];
    public int[] colors2;

    public BouncingBallInside(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BouncingBallInside(Context context, int numBalls) {
        super(context);
        this.numBalls = numBalls;
        init();
    }

    private void init() {
        //Lista de colores
        colors = new Integer[]{Color.RED, Color.BLUE, Color.GREEN,
                Color.CYAN, Color.GRAY, Color.YELLOW, Color.MAGENTA,
                Color.rgb(203, 133, 0), Color.rgb(171, 203, 0),
                Color.rgb(104, 0, 203), Color.rgb(203, 0, 167)};
        //Depende del numero de bolas es el nivel
        if (numBalls == 4) {
            //genero 2 colores random
            int random1 = (int) ((Math.random() * (colors.length - 0)) + 0);
            int random2 = (int) ((Math.random() * (colors.length - 0)) + 0);
            colors2 = new int[]{colors[random1], colors[random2]};
            //Crei 4 bolas con datos ramdon y colores random pero solo de los dos colores de justo encima
            for (int i = 0; i < numBalls; i++) {
                int random = (int) ((Math.random() * (colors2.length - 0)) + 0);
                int positionx = (int) ((Math.random() * (1000 - 100)) + 100);
                int positiony = (int) ((Math.random() * (1000 - 100)) + 100);
                int size = (int) ((Math.random() * (100 - 50)) + 50);
                int speed = (int) ((Math.random() * (30 - 10)) + 10);
                balls.add(new Ball(positionx, positiony, size, colors2[random], speed));
            }
        }
        if (numBalls == 6) {
            int random1 = (int) ((Math.random() * (colors.length - 0)) + 0);
            int random2 = (int) ((Math.random() * (colors.length - 0)) + 0);
            int random3 = (int) ((Math.random() * (colors.length - 0)) + 0);
            colors2 = new int[]{colors[random1], colors[random2], colors[random3]};
            for (int i = 0; i < numBalls; i++) {
                int random = (int) ((Math.random() * (colors2.length - 0)) + 0);
                int positionx = (int) ((Math.random() * (1000 - 100)) + 100);
                int positiony = (int) ((Math.random() * (1000 - 100)) + 100);
                int size = (int) ((Math.random() * (100 - 50)) + 50);
                int speed = (int) ((Math.random() * (40 - 10)) + 10);
                balls.add(new Ball(positionx, positiony, size, colors2[random], speed));
            }
        }
        if (numBalls == 8) {
            int random1 = (int) ((Math.random() * (colors.length - 0)) + 0);
            int random2 = (int) ((Math.random() * (colors.length - 0)) + 0);
            int random3 = (int) ((Math.random() * (colors.length - 0)) + 0);
            int random4 = (int) ((Math.random() * (colors.length - 0)) + 0);
            colors2 = new int[]{colors[random1], colors[random2], colors[random3], colors[random4]};
            for (int i = 0; i < numBalls; i++) {
                int random = (int) ((Math.random() * (colors2.length - 0)) + 0);
                int positionx = (int) ((Math.random() * (1000 - 100)) + 100);
                int positiony = (int) ((Math.random() * (1000 - 100)) + 100);
                int size = (int) ((Math.random() * (100 - 50)) + 50);
                int speed = (int) ((Math.random() * (50 - 10)) + 10);
                balls.add(new Ball(positionx, positiony, size, colors2[random], speed));
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        //Draw the balls
        for (Ball ball : balls) {
            //Move first
            ball.move(canvas);
            //Draw them
            canvas.drawOval(ball.oval, ball.paint);
        }
        //Tiempo del juego y contador hasta terminar la pantalla
        final int sec = 15000;
        CountDownTimer countDownTimer = new CountDownTimer(sec, 1000) {

            public void onTick(long millisUntilFinished) {
                int second = (int) (millisUntilFinished / 1000) % 60;
            }

            public void onFinish() {
                //Cuando pasan 15 segundos cambio de fragmento y envio datos para comprobar todo
                Bundle bundle = new Bundle();
                bundle.putParcelableArrayList("balls", balls);
                bundle.putIntArray("colors2", colors2);
                NavController navController = Navigation.findNavController((Activity) getContext(),
                        R.id.nav_host_fragment_content_main);
                navController.navigateUp();
                navController.navigate(R.id.endGameFragment, bundle);
            }
        };
        countDownTimer.start();//Comienza el contador
        invalidate(); // See note
    }
}