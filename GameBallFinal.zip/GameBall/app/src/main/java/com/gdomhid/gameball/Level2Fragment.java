package com.gdomhid.gameball;

import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.gdomhid.gameball.databinding.FragmentLevel2Binding;

import java.io.IOException;

public class Level2Fragment extends Fragment {

    private FragmentLevel2Binding binding;
    private MediaPlayer player;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentLevel2Binding.inflate(inflater, container, false);
        return new BouncingBallInside(getContext(), 6);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        try {
            //pongo musica de fondo
            player = new MediaPlayer();
            AssetFileDescriptor afd = getContext().getAssets().openFd("10.DJVI - xStep.mp3");
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            player.prepare();
            player.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //Paro la musica
        if (player != null) {
            player.release();
            player = null;
        }
        binding = null;
    }
}